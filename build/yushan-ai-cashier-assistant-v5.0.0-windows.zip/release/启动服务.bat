@echo off
chcp 65001 >nul
title 雨姗AI收银助手 v5.0.0

cd /d "%~dp0"

echo ============================================
echo 雨姗AI收银助手 v5.0.0
echo ============================================
echo.

echo [检查] 正在检查环境...
echo.

REM 检查 Node.js
node --version >nul 2>&1
if %errorlevel% neq 0 (
  echo [错误] 未检测到 Node.js 18+！
  echo.
  echo 请先安装 Node.js 18.x LTS:
  echo https://nodejs.org/zh-cn/
  echo.
  pause
  exit /b 1
)
echo [OK] Node.js 已安装

REM 检查 node_modules
if not exist "node_modules" (
  echo.
  echo [提示] 首次运行，正在安装依赖（需要1-3分钟）...
  echo.
  call npm install --omit=dev
  if %errorlevel% neq 0 (
    echo.
    echo [错误] 依赖安装失败！
    pause
    exit /b 1
  )
  echo.
  echo [完成] 依赖安装成功！
  echo.
)

REM 初始化SQLite数据库
if not exist "lambda\data\cashier.db" (
  echo [提示] 正在初始化数据库...
  echo.
  node lambda\database\init-sqlite.js
  if %errorlevel% neq 0 (
    echo [警告] 数据库初始化可能存在问题，继续启动...
  )
  echo.
)

echo ============================================
echo 服务启动中，请勿关闭此窗口...
echo.
echo 打开浏览器访问: http://localhost:3000
echo ============================================
echo.

cd lambda
node server.js