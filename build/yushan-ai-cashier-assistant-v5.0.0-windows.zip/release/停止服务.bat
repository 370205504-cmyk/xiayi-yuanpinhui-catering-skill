@echo off
chcp 65001 >nul
title 停止雨姗AI收银助手
cd /d "%~dp0"

echo 正在停止服务...
taskkill /f /im node.exe 2>nul
echo 服务已停止
pause