@echo off
chcp 65001 >nul
title 初始化数据库
cd /d "%~dp0"

echo ============================================
echo 初始化SQLite数据库
echo ============================================
echo.

if not exist "node_modules" (
  echo [错误] 请先运行 启动服务.bat 安装依赖
  pause
  exit /b 1
)

echo 正在初始化数据库...
echo.
node lambda\database\init-sqlite.js
echo.
echo ============================================
echo 数据库初始化完成！
echo ============================================
pause